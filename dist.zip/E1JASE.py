cal1 = int(input("Ingresa su calificacion 1era Act:" ))
cal2 = int(input("Ingresa su calificacion 1er parcial:" ))
cal3 = int(input("Ingresa su calificacion 2da Act:" )) 
cal4 = int(input("Ingresa su calificacion 2do parcial:" ))
cal5 = int(input("Ingresa su calificacion 3era Act:" ))
cal6 = int(input("Ingresa su calificacion 3er parcial:"))
cal7 = int(input("Ingresa su calificacion 1er parcial:" ))  
Prom = cal1 + cal2 + cal3 // 3
if Prom >= 70:
    print("Usted esta Aprobado")
if Prom <= 69:
    print("Usted esta Reprobado") 

print("Fin del programa")